<?php
class ControllerExtensionModuleBrand extends Controller {
	public function index($setting) {

		$this->load->language('extension/module/brand');

		$this->load->model('catalog/manufacturer');

		$this->load->model('tool/image');

		$data['brands'] = array();


		// Если есть значения лимита то присваиеваем. Иначе не передаем параметров чтобы не было лимита по умолчанию в методе getManufacturers
		if ($setting['limit']) {
			$filter_data = array(
				'limit' => $setting['limit']
			);
			$results = $this->model_catalog_manufacturer->getManufacturers($filter_data);
		} else {
			$results = $this->model_catalog_manufacturer->getManufacturers();
		}

		if ($results) {

			$data['template_name'] = $setting['name'];

			foreach ($results as $result) {

				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $setting['width'], $setting['height']);
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $setting['width'], $setting['height']);
				}

				$data['brands'][] = array(
					'name'  => $result['name'],
					'thumb' => $image,
					'href'  => $this->url->link('product/manufacturer/info', 'manufacturer_id=' . $result['manufacturer_id'])
				);
			}

			return $this->load->view('extension/module/brand', $data);
		}

	}
}